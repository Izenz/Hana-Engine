#pragma once

#ifdef MATH_VEC_IS_FLOAT4
#include "float4.h"
#else
#include "float2.h"
#endif
